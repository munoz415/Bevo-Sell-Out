var itemDetails=[];
itemDetails.push(["Asking Price", "item", "Image"]);
itemDetails.push(["", "Chair", "25.99"]);
itemDetails.push(["", "Leaf Art", "15.00"]);
itemDetails.push(["", "Desk" ,  "65.00"]);
itemDetails.push(["", "Lava Lamp", "10.00"]);
itemDetails.push(["", "Table", "24.99"]);
itemDetails.push(["", "Coffee Maker" , "35.50"]);

itemDetails[1][0] = new Image();
itemDetails[1][0].src = 'chair.png';

itemDetails[2][0] = new Image();
itemDetails[2][0].src = 'decor.png';

itemDetails[3][0] = new Image();
itemDetails[3][0].src = 'desk.jpg';

itemDetails[4][0] = new Image();
itemDetails[4][0].src = 'lamp.jpg';

itemDetails[5][0] = new Image();
itemDetails[5][0].src = 'table.jpg';

itemDetails[6][0] = new Image();
itemDetails[6][0].src = 'coffeemaker.jpg';
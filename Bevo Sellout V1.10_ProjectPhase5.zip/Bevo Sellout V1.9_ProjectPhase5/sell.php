<?php
$name = $_POST["name"];
$condition = $_POST["condition"];
$price = $_POST["price"];
$product = $_POST["product"];
$comments = $_POST["comments"];


$file = fopen("sell.txt", "w");

$out1 = "name: ". $name . "\n";
fwrite($file, $out1);

$out2 = "condition: ". $condition . "\n";
fwrite($file, $out2);

$out3 = "price: ". $price . "\n";
fwrite($file, $out3);

$out4 = "product: ". $product . "\n";
fwrite($file, $out4);

$out5 = "comments: ". $comments . "\n";
fwrite($file, $out5);

fclose($file);

echo'<script>
window.alert("Data recorded")
window.location.href = "home.html"
</script>';
    
    
    


?>

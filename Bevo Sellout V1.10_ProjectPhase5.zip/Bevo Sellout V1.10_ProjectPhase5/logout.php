<?php
	$name = $_COOKIE["auth"];
	setcookie("auth", $name, time()-3600, '/');
	echo '<script>
		window.alert("Logged out")
		window.location.href = "home.php"
	</script>';
?>

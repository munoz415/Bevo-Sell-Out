<?php
    $name  = $_POST["name"];
    $password = $_POST["password"];
    $file = fopen("passwd.txt", "r");
    $passed = false;

    //check to see if name and password match in database
    while(!feof($file)) {
        $line = fgets($file);
        $split = explode(":", $line);
        if(trim($split[0]) == trim($name) && trim($split[1]) == trim($password)) {
            //cookie only lasts two minutes for testing purposes
            setcookie("auth", $name, time() + 60*2, '/');
            echo '<script>
		window.alert("Login Successful")
		window.location.href = "home.php"
            </script>';
            $passed = true;
        }
    }

    fclose($file);

    if(!$passed) {
        echo ' <script>
	    window.alert("Login Failed")
	    window.location.href = "login.html"
        </script>'; 
    }
?>

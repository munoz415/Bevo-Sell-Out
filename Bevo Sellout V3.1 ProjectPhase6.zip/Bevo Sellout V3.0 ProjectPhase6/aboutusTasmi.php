<!DOCTYPE html>

<html lang="en">

<head>
   <title>About Tasmi</title>
   <meta charset="UTF-8">
   <meta name="description" content="About Tasmi">
   <meta name="author" content="Johnathan Huijon">
    <link href="aboutus.css" rel = "stylesheet">
</head> 

<body>
    <div id="container">
        <div id="top">
            <a href="home.php"><img id="logo" src="logo.png" ></a>
            <?php
            if(!isset($_COOKIE["auth"])) {
                echo '<a id="signup" href="register.html">Register</a>
                <a id="signup" href="login.html">Login</a>';
            } else {
                echo '<a id="signup" href="logout.php">Log out</a>';
            }
            ?>
            <a href="home.php"><h1>BEVO SELL-OUT</h1></a>
        </div> 
        
        
        <div class="navbar">
              <div class="dropdown">
                <button class="dropbtn">About Us 
                    <i class="fa fa-caret-down"></i>
                </button>
            <div class="dropdown-content">
                <a href="aboutusTasmi.php">Tasmi</a>
                <a href="aboutusJohny.php">Johny</a>
                <a href="aboutusHarper.php">Harper</a>
                <a href="aboutusMark.php">Mark</a>
                <a href="aboutusGroup.php">Group 24</a>
                
            </div>
            </div>
            
          
            <a href="home.php">Home</a>
            <a href="bookmarks.php">Saved</a>
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
        </div> 
        
        
        
        <div id="content">
            <h2>About Us</h2>
            
            <div class = "box"> 
                
                <div id="name">Tasmi</div>
                <div class = "box darker"> 
                    
                    <div id = "info">
                        Hi my name is Tasmi Islam. I'm a senior AET major at UT focusing on Game Development. <br>
                        <br>
                        I have worked on many collaborative projects and have published an IOS game called Halo Jump with my team.
                        <br>
                        <br>
                        I have been coding for 5 years and have knowledge in Python, Swift, C#, and Java.<br><br><br><br>
                        
                        <div id = "contact"> Contact: <a href = "mailto: tasmiah.i.15@gmail.com">tasmiah.i.15@gmail.com</a> </div>
                    </div>
                    
                    <img src="Tasmi.JPG" alt="Profile Picture" style="width: 25%">
                    
                    
                    
                    
                </div>
            
            </div>
            
            
        </div>
 
        <div id="footer">
            © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
        </div>
    </div>

</body>
</html>
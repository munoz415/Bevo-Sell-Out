var status = "false";

var galleryPhotos = [];


var imageIndex = 0;

function addToGalleryPhotos(filePath){
    
    //alert("we getting here");
    console.log(filePath);
    galleryPhotos.push(filePath);
    
    //alert('Execute Javascript Function Through PHP');

    
}


function leftChange(){
    
    if (imageIndex > 0){
        imageIndex--;
    }
    else{
        imageIndex = galleryPhotos.length-1;
    }
    document.galleryImage.src = galleryPhotos[imageIndex];
}

function rightChange(){
    
    if (imageIndex < galleryPhotos.length - 1){
        imageIndex++;
    }
    else{
        imageIndex = 0;
    }
    
    document.galleryImage.src = galleryPhotos[imageIndex];
}

function notInterestedText(){
    
    var element = document.getElementById("noMessage");
    element.style.display = "none";
    
    document.getElementById('interest').innerText = 'Interested In Buying?';
    document.getElementById('interestedMessage').innerText = 'Pressing this button will reveal the sellers contact inforamtion.';
    

}

function InterestedText(){
    var element = document.getElementById("noMessage");
    element.style.display = "block";
    
    document.getElementById('interest').innerText = 'No longer Interested?';
    document.getElementById('interestedMessage').innerText = 'Pressing this button will not give you access to seller\'s contact information';
}

function changeText(){
    if (status == "true"){
        notInterestedText();
        status = "false"
    }
    else{
        InterestedText();
        status = "true"
    }
}


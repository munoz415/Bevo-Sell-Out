function register() {
    var name = document.getElementById("name").value
    var password = document.getElementById("password").value
    var confirmPassword = document.getElementById("repeatPassword").value
    var hasLower = false
    var hasUpper = false
    var hasDigit = false

    //check if length of name is right
    if (name.length < 6 || name.length > 10) {
        window.alert("Invalid username or password")
        return
    }

    //check if name start with a number
    if (isNaN(name[0]) == false) {
        window.alert("Invalid username or password")
        return
    }

    //check if both passwords are the same
    if (password !== confirmPassword) {
        window.alert("Invalid username or password")
        return
    }

    //check if length of password is right
    if (password.length < 6 || password.length > 10) {
        window.alert("Invalid username or password")
        return
    }

    //check if all characters in name are valid
    for (let i = 0; i < name.length; i++) {
        if (isNotChar(name[i])){
            window.alert("Invalid username or password")
            return
        }
    }

    //check if all characters in name are valid and if there is a lower case, upper case, and digit
    for (let i = 0; i < password.length; i++) {
        if (isNotChar(password[i])){
            window.alert("Invalid username or password")
            return
        } 
        if (password.charCodeAt(i) >= 97 && password.charCodeAt(i) <= 122) {
            hasLower = true
        }
        if (password.charCodeAt(i) >= 48 && password.charCodeAt(i) <= 57) {
            hasDigit = true
        }
        if (password.charCodeAt(i) >= 65 && password.charCodeAt(i) <= 90) {
            hasUpper = true
        }
    }

    //check if password has a lower case, upper case, and digit
    if ((hasLower && hasUpper && hasDigit) == false) {
        window.alert("Invalid username or password")
        return
    }

    window.alert("User validated")

    return
}

function isNotChar(charac) {
    if ((charac.charCodeAt(0) < 97 || charac.charCodeAt(0) > 122) && (charac.charCodeAt(0) < 48 || charac.charCodeAt(0) > 57)){
        if (charac.charCodeAt(0) < 65 || charac.charCodeAt(0) > 90) {
            return true
        }
    }
}

window.onload = function () {
    $("form").submit(function (e) {
        e.preventDefault();
        register();
        return false;
    });
}
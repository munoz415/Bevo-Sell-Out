<?php
    error_reporting(E_ALL);
    ini_set("display_errors", "on");
    
    $server = "spring-2022.cs.utexas.edu";
    $user   = "cs329e_bulko_mam25499";
    $pwd    = "Sweden*React-Clay";
    $dbName = "cs329e_bulko_mam25499";
    
    // Connect to MySQL Server

 
    $mysqli = new mysqli($server, $user, $pwd, $dbName);
 
    if ($mysqli->connect_errno) {
       die('Connect Error: ' . $mysqli->connect_errno . ": " .  $mysqli->connect_error);
    }
	

    //Select Database
    $mysqli->select_db($dbName) or die($mysqli->error);
    
    // Retrieve data from Query String and Post
    $name = $_GET['name'];
    $password = $_GET['password']; 

    // Escape User Input to help prevent SQL Injection
    $name = $mysqli->real_escape_string($name);
    $password = $mysqli->real_escape_string($password);
 
    //build query 
    $query = "SELECT nombre FROM projPass WHERE nombre = '$name'";
    
    //Execute query 
    $result = $mysqli->query($query) or die($mysqli->error);
 
    //Build Result String
    $exists = False;
    while($row = $result->fetch_row()) {
        $exists = True;
        $sName = $row[0];
    }
 
    //if name is in database
    if($exists) {
         $query = "SELECT passwd FROM projPass WHERE nombre = '$name'";
        $result = $mysqli->query($query) or die($mysqli->error);
	 $sPwd = $result->fetch_row()[0];
        //if name and password match
         if($name == $sName && $password == $sPwd) {
             //cookie only lasts two minutes for testing purposes
             setcookie("auth", $name, time() + 60*120);
             echo "<p>User has logged in</p>";
         } else if($name == $sName && $password != $sPwd) {
             //if name matches but not password
             echo "<p>Login Failed</p>";
         } 
    } else {
         //if name not in database
         echo "<p>Login Failed</p>";
    }
?>

<?php
	$name = $_COOKIE["auth"];
	setcookie("auth", "", time()-60*120);
	echo '<script>
		window.alert("Logged out")
		window.location.href = "home.php"
	</script>';
?>

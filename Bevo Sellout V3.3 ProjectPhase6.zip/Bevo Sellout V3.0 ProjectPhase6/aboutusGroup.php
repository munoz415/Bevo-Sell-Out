<!DOCTYPE html>

<html lang="en">

<head>
   <title>About the Group</title>
   <meta charset="UTF-8">
   <meta name="description" content="Sell your items here">
   <meta name="author" content="Johnathan Huijon">
    <link href="aboutus.css" rel = "stylesheet">
</head> 

<body>
    <div id="container">
        <div id="top">
            <a href="home.php"><img id="logo" src="logo.png" ></a>
            <?php
            if(!isset($_COOKIE["auth"])) {
                echo '<a id="signup" href="register.html">Register</a>
                <a id="signup" href="login.html">Login</a>';
            } else {
                echo '<a id="signup" href="logout.php">Log out</a>';
            }
            ?>
            <a href="home.php"><h1>BEVO SELL-OUT</h1></a>
        </div> 
        
        
        <div class="navbar">
              <div class="dropdown">
                <button class="dropbtn">About Us 
                    <i class="fa fa-caret-down"></i>
                </button>
            <div class="dropdown-content">
                <a href="aboutusTasmi.php">Tasmi</a>
                <a href="aboutusJohny.php">Johny</a>
                <a href="aboutusHarper.php">Harper</a>
                <a href="aboutusMark.php">Mark</a>
                <a href="aboutusGroup.php">Group 24</a>
                
            </div>
            </div>
            
            <a href="home.php">Home</a>
            
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
        </div> 
        
        
        
        <div id="content">
            <h2>About Us</h2>
            <div class = "box"> 
                
                <div id="name">Team 24</div>
                
                <div class = "box darker"> 
                    
                    <div id = "info">
                        Our group is a subset of the Spring 2022 Web Development class at the University of Texas at Austin
                        taught by Professor Bulko. <br><br>
                        Our group consists of Johnathan, Tasmi, Harper, and Mark. You can read more about the group members on their respecitve about us page. <br><br>
                        We decided to make a website where students in and around West Campus can buy or sell apartment furnishings all in one place.
                    </div>
                    
                    <img src="team.png" alt="Profile Picture" style="width: 30%">
                    
                            
                    
                </div>
            
            </div>
            
        </div>

        <div id="footer">
            © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
        </div>
    </div>

</body>
</html>
var status = "false";

var galleryPhotos = new Array("chair.png", "table.jpg", "lamp.jpg", "desk.jpg", "decor.png")

var imageIndex = 0;

function leftChange(){
    
    if (imageIndex > 0){
        imageIndex--;
    }
    else{
        imageIndex = galleryPhotos.length-1;
    }
    document.galleryImage.src = galleryPhotos[imageIndex];
}

function rightChange(){
    
    if (imageIndex < galleryPhotos.length - 1){
        imageIndex++;
    }
    else{
        imageIndex = 0;
    }
    
    document.galleryImage.src = galleryPhotos[imageIndex];
}

function notInterestedText(){
    
    var element = document.getElementById("noMessage");
    element.style.display = "none";
    
    document.getElementById('interest').innerText = 'Interested In Buying?';
    document.getElementById('interestedMessage').innerText = 'Pressing this button will reveal the sellers contact inforamtion. An email will also be sent to the seller with your contact information.';
    

}

function InterestedText(){
    var element = document.getElementById("noMessage");
    element.style.display = "block";
    
    document.getElementById('interest').innerText = 'No longer Interested?';
    document.getElementById('interestedMessage').innerText = 'Pressing this button will notify the seller that you are no longer interested. Additionally this item will also be removed from your bookmarks';
}

function changeText(){
    if (status == "true"){
        notInterestedText();
        status = "false"
    }
    else{
        InterestedText();
        status = "true"
    }
}


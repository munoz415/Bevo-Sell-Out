<?php

    error_reporting(E_ALL);
    ini_set("display_errors", "on");


   function filterTable($query)
   {
   $mysqli = mysqli_connect("spring-2022.cs.utexas.edu", "cs329e_bulko_jh68526", "Club8Pillow2affect", "cs329e_bulko_jh68526");
   $filter_Result = mysqli_query($mysqli, $query);
   
   return $filter_Result;
   }

   function imageId($id)
   {
    $id = intval($id);

    $mysqli = new mysqli("spring-2022.cs.utexas.edu", "cs329e_bulko_jh68526", "Club8Pillow2affect", "cs329e_bulko_jh68526");
       
    $mysqli->select_db('cs329e_bulko_jh68526') or die($mysqli->error);
       
    $query_image = "SELECT * FROM images WHERE item_id = '$id' AND primary_img = 1";
       
       
    $filter_Result_image = $mysqli->query($query_image) or die($mysqli->error);

       
    while($row = mysqli_fetch_array($filter_Result_image)){
        
        $filePath = 'picUpload/' . $row[0] . '.' . $row[4];

        return $filePath;

   }


    return $filePath;
   }

   function amazonString($itemStr)
   {
    return str_replace(' ', '+', $itemStr);
   }

?>



<!DOCTYPE html>

<html lang="en">

<head>
   <title>Search Page</title>
   <meta charset="UTF-8">
   <meta name="description" content="Item Page">
   <meta name="author" content="Harper DeLoach">
   
   <link href="search.css" rel="stylesheet">
   <script type="text/javascript" src="search.js"> </script>
   <script src = "jquery-3.6.0.js"></script>
    

</head> 

<body>

   <div id="container">
      <div id="top">
          <a href="home.php"><img id="logo" src="logo.png" ></a>
          <?php
          if(!isset($_COOKIE["auth"])) {
              echo '<a id="signup" href="register.html">Register</a>
              <a id="signup" href="login.html">Login</a>';
          } else {
              echo '<a id="signup" href="logout.php">Log out</a>';
          }
          ?>
          <a href="home.html"><h1>BEVO SELL-OUT</h1></a>
      </div>        
      
      <div class="navbar">
          <div class="dropdown">
              <button class="dropbtn">About Us 
                  <i class="fa fa-caret-down"></i>
              </button>
          <div class="dropdown-content">
              <a href="aboutusTasmi.php">Tasmi</a>
              <a href="aboutusJohny.php">Johny</a>
              <a href="aboutusHarper.php">Harper</a>
              <a href="aboutusMark.php">Mark</a>
              <a href="aboutusGroup.php">Group 24</a>
              
          </div>
          </div>
          
            <a href="home.php">Home</a>
            <a href="bookmarks.php">Bookmarks</a>
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
       </div>



  <form action="search.php" method="post">

    <input type="text" name="valueToSearch" placeholder="Item">
    <br><br>
    <input type="submit" name="search" value="Search Items"><br><br>

    <table class="results" border="1px solid grey;">
        <tr>
            <td>Item</td>
            <td>Picture</td>
            <td>Condition</td>
            <td>Price</td>
       </tr>

       
       <?php
            global $search_result;
            $query = "SELECT * FROM seller";
            $search_result = filterTable($query);
        
            if(isset($_POST['search'])) {
        
               $valueToSearch = $_POST['valueToSearch'];
        
               $query = "SELECT * FROM seller WHERE item_name LIKE '%$valueToSearch%'";
        
               $search_result = filterTable($query);
        
            }
        
            $itemArray = [];
            $itemIndex = 0;
            $clickedIndex = 0;
        
            
                
            while($row = $search_result -> fetch_row()) {
                
                
                $name = $row[3];
                
                
                echo '<tr><td> <a href = \'item.php?item_id=' . $row[0] . '\'> ' . $name . ' </a> </td>';
                $img_id = imageId($row[0]);
                echo '<td> <img src= \'' . $img_id . '\'alt="Item"> </td>';
                $condition = $row[4];
                echo '<td>'.$condition.'</td>';
                $price = $row[5];
                echo '<td> $'.$price.'</td>';

            }
        ?>


    </table>
  </form>
      
       <div id="footer">
            © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
       </div>
       
   </div>

</body>
<!DOCTYPE html>

<html lang="en">

<head>
   <title>Bevo Sell-Out</title>
   <meta charset="UTF-8">
   <meta name="description" content="Sell your items here">
   <meta name="author" content="Johnathan Huijon">
    <link href="home.css" rel = "stylesheet">
    <script type = "text/javascript" src = "homeShow.js"></script>
</head> 

<body onload="startShow()">
    <div id="container">
        <div id="top">
            <a href="home.php"><img id="logo" src="logo.png" ></a>
            
            <?php
            if(!isset($_COOKIE["auth"])) {
                echo '<a id="signup" href="register.html">Register</a>
                <a id="signup" href="login.html">Login</a>';
            } else {
                echo '<a id="signup" href="logout.php">Log out</a>';
            }
            ?>
  
            <a href="home.php"><h1>BEVO SELL-OUT</h1></a>
            
        </div>        
        
        <div class="navbar">
              <div class="dropdown">
                <button class="dropbtn">About Us 
                    <i class="fa fa-caret-down"></i>
                </button>
            <div class="dropdown-content">
                <a href="aboutusTasmi.php">Tasmi</a>
                <a href="aboutusJohny.php">Johny</a>
                <a href="aboutusHarper.php">Harper</a>
                <a href="aboutusMark.php">Mark</a>
                <a href="aboutusGroup.php">Group 24</a>
                
            </div>
            </div>
          
            <a href="home.php">Home</a>
            <a href="bookmarks.php">Bookmarks</a>
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
        </div>        
        

        <div id="content">
            <div class = "box"> 
                <hr>
                WHAT ARE WE ABOUT
                <hr>
                <div class = "box darker"> 

                    Buy or sell around west campus to reduce 
                waste at the end of the semester! <a href="sell.php">More</a>


                </div>

            </div>     
            
              <div class = "box2"> 
                <hr>
                TOP PICKS FOR YOU!
                <hr>
                <div class = "box2 darker2"> 
                    <img id = "image" src="chair.png" style="width: 20%">
                    <p>
                        <button type="button" id="start" onclick="startShow()">Resume</button>
                        <button type="button" id="end" onclick="stopShow()">Pause</button>
                    </p>
                </div>

            </div>

        </div>

        <div id="footer">
            © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
        </div>
    </div>

</body>
</html>

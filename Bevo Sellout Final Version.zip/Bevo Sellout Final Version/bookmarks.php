<!DOCTYPE html>

<html lang="en">

<head>
   <title>Bookmarks</title>
   <meta charset="UTF-8">
   <meta name="description" content="Bookmarks page">
   <meta name="author" content="Harper DeLoach">
   
   <link href="search.css" rel="stylesheet">
   <script type="text/javascript" src="search.js"> </script>
   <script src = "jquery-3.6.0.js"></script>
</head> 

<body>

   <div id="container">
      <div id="top">
          <a href="home.php"><img id="logo" src="logo.png" ></a>
          <?php
          if(!isset($_COOKIE["auth"])) {
              echo '<a id="signup" href="register.html">Register</a>
              <a id="signup" href="login.html">Login</a>';
          } else {
              echo '<a id="signup" href="logout.php">Log out</a>';
          }
          ?>
          <a href="home.php"><h1>BEVO SELL-OUT</h1></a>
      </div>        
      
      <div class="navbar">
          <div class="dropdown">
              <button class="dropbtn">About Us 
                  <i class="fa fa-caret-down"></i>
              </button>
          <div class="dropdown-content">
              <a href="aboutusTasmi.php">Tasmi</a>
              <a href="aboutusJohny.php">Johny</a>
              <a href="aboutusHarper.php">Harper</a>
              <a href="aboutusMark.php">Mark</a>
              <a href="aboutusGroup.php">Group 24</a>
              
          </div>
          </div>
          
            <a href="home.php">Home</a>
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
            <a href="tutorial.php">Tutorial</a>
       </div>

      <div class='results'>
          
          <?php
          
          if(!isset($_COOKIE["auth"])) {
              
              echo "<h3>Must Be Logged In To Check Your Bookmarks!</h3>";
              
              exit();
              
          }
          
          ?>
         <table>
            <tr>
               <td><input type="text" id="search_bar" name="search_bar" placeholder="Search For items"></td>
               <td><button id="search_button">Search</button></td>
            </tr>
         </table>
         <br>
         <div id="results">
         </div>
      </div>
       <div id="footer">
            © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
        </div>
       
   </div>

</body>

<script>
   $(window).on('load', function (e) {
    e.preventDefault();
    var resultsDiv = $("#results");
    resultsDiv.html("");
    var Table = $("<table>", {
        "id": "newTable"
    }).appendTo(resultsDiv);
    var rowCount = itemDetails.length;
    var colmCount = itemDetails[0].length;

    // For loop for adding header .i.e th to our table
    for (var k = 0; k < 1; k++) {
        var tablePop = $("<tr>", {
            "class": "trClass"
        }).appendTo(Table);
        for (var j = 0; j < colmCount + 1; j++) {
            if (j == 3) {
               $("<th>", {
                "class": "thClass"
            }).prependTo(tablePop).html('Remove');
            } else {
               $("<th>", {
                "class": "thClass"
            }).prependTo(tablePop).html(itemDetails[k][j]);
            }
        }
    }

    //For loop for adding data .i.e td with data to our dynamic generated table
    for (var i = 1; i < rowCount; i < i++) {
        var tablePop = $("<tr>", {
            "class": "trClass"
        }).appendTo(Table);
        for (var j = 0; j < colmCount + 1; j++) {
            if (j == 0) {
               $("<td>", {
               "class": "tdClass"
               }).appendTo(tablePop).html('<button id="item_button"><a href="item.php">Item</a></button>');
            } else {
               $("<td>", {
               "class": "tdClass"
               }).appendTo(tablePop).html(itemDetails[i][j-1]);
            }
             
        }
    }
});

   $("#item_button").on('click', function (e) {
      window.location.href = 'item.php'
});
</script>
</html>
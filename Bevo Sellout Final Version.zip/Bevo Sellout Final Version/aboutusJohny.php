<!DOCTYPE html>

<html lang="en">

<head>
   <title>About Johny</title>
   <meta charset="UTF-8">
   <meta name="description" content="Sell your items here">
   <meta name="author" content="Johnathan Huijon">
    <link href="aboutus.css" rel = "stylesheet">
</head> 

<body>
    <div id="container">
        <div id="top">
            <a href="home.php"><img id="logo" src="logo.png" ></a>
            <?php
            if(!isset($_COOKIE["auth"])) {
                echo '<a id="signup" href="register.html">Register</a>
                <a id="signup" href="login.html">Login</a>';
            } else {
                echo '<a id="signup" href="logout.php">Log out</a>';
            }
            ?>
            <a href="home.php"><h1>BEVO SELL-OUT</h1></a>
        </div> 
        
        
        <div class="navbar">
              <div class="dropdown">
                <button class="dropbtn">About Us 
                    <i class="fa fa-caret-down"></i>
                </button>
            <div class="dropdown-content">
                <a href="aboutusTasmi.php">Tasmi</a>
                <a href="aboutusJohny.php">Johny</a>
                <a href="aboutusHarper.php">Harper</a>
                <a href="aboutusMark.php">Mark</a>
                <a href="aboutusGroup.php">Group 24</a>
                
            </div>
            </div>
            
            <a href="home.php">Home</a>
            
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
            <a href="tutorial.php">Tutorial</a>
        </div> 
        
        
        
        <div id="content">
            <h2>About Us</h2>
            <div class = "box"> 
                
                <div id="name">Johny</div>
                <div class = "box darker"> 
                    
                    
                    
                    <div id = "info">
                        My name is Johnathan Huijon and i'm a third year Anthropolgy <br><br> major. I've been in 2 collabrotive CS projects during my time at <br><br> the University of Texas at Austin and I have experience coding <br><br> in Python, Swift, & Javascript. <br><br>
                        <div id = "contact"> Contact: <a href = "mailto: johnathan.huijon@gmail.com">johnathan.huijon@gmail.com</a> </div>
                    </div>
                    
                    <img src="Johny.jpg" alt="Profile Picture" style="width: 30%">
                    
                    
                    
                    
                </div>
            
            </div>
            
        </div>
        
        <div id="footer">
            © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
        </div>
    </div>

</body>
</html>

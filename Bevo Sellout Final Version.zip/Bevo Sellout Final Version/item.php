<!DOCTYPE html>

<html lang="en">

<head>
   <title>Item Page</title>
   <meta charset="UTF-8">
   <meta name="description" content="Item Page">
   <meta name="author" content="Johnathan Huijon">
   
   <link href="item.css" rel="stylesheet">
   <script type="text/javascript" src="item.js"> </script>
</head> 
    
<?php

error_reporting(E_ALL);
ini_set("display_errors", "on");
include_once 'dbConnect.php';

$item_id = $_GET['item_id'];

$mysqli->select_db('cs329e_bulko_jh68526') or die($mysqli->error);
       
$query = "SELECT * FROM seller WHERE item_id = $item_id ";



//echo $query;

$item_result = $mysqli->query($query) or die($mysqli->error);
    
       
$sellerRow = mysqli_fetch_array($item_result);
    
$sellers_user = $sellerRow['sellers_user'];
$date_listed = $sellerRow['date_listed'];
$item_condition = $sellerRow['item_condition'];
$item_name = $sellerRow['item_name'];
$price_listing = $sellerRow['price_listing'];
$product_type = $sellerRow['product_type'];
$item_description = $sellerRow['item_description'];

$query_image = "SELECT * FROM images WHERE item_id = '$item_id' ";

$image_result = $mysqli->query($query_image) or die($mysqli->error);


    
while($imageRow = mysqli_fetch_array($image_result)){
        
    $filePath = 'picUpload/' . $imageRow[0] . '.' . $imageRow[4];

    
    echo '<script type="text/javascript">addToGalleryPhotos(\'' . $filePath . '\');</script>';

}


$query_primary_image = "SELECT * FROM images WHERE item_id = '$item_id' AND primary_img = 1";
    
$primary_image_result = $mysqli->query($query_primary_image) or die($mysqli->error);
    
$primaryRow = mysqli_fetch_array($primary_image_result);
    
$primaryFilePath = 'picUpload/' . $primaryRow[0] . '.' . $primaryRow[4];

function amazonString($itemStr)
{
    return str_replace(' ', '+', $itemStr);
}

?>

<body onload = "notInterestedText()">

   <div id="container">
      <div id="top">
            <a href="home.php"><img id="logo" src="logo.png" ></a>
            <?php
            if(!isset($_COOKIE["auth"])) {
                echo '<a id="signup" href="register.php">Register</a>
                <a id="signup" href="login.html">Login</a>';
            } else {
                echo '<a id="signup" href="logout.php">Log out</a>';
            }
            ?>
            <a href="home.php"><h1>BEVO SELL-OUT</h1></a>
      </div>        
      
      <div class="navbar">
          <div class="dropdown">
              <button class="dropbtn">About Us 
                  <i class="fa fa-caret-down"></i>
              </button>
          <div class="dropdown-content">
              <a href="aboutusTasmi.php">Tasmi</a>
              <a href="aboutusJohny.php">Johny</a>
              <a href="aboutusHarper.php">Harper</a>
              <a href="aboutusMark.php">Mark</a>
              <a href="aboutusGroup.php">Group 24</a>
              
          </div>
          </div>
          
            <a href="home.php">Home</a>
            
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
            <a href="tutorial.php">Tutorial</a>
       </div>
       
       <div class = "leftSide">
           
           <div class = "gallery">
               
               <?php 
               
               echo "<span class=\"helper\"></span><img name = \"galleryImage\" id = \"image\" src= \"" . $primaryFilePath . "\">";
               
               ?>

           </div>
           
           <div class = galleryButtons>
               
               <button type="button" id="start" onclick="leftChange()">&lt;</button>
               <button type="button" id="start" onclick="rightChange()">&#62;</button>
               
           </div>
           
           <div class = "ContactInfo">
               
               <div class = "interestButton">
                   <button type="button" id="interest" onclick="changeText()">Interested In Buying?</button>
               </div>
               <div class = "interestedMessage">
                   <p id = "interestedMessage">
                       Pressing this button will reveal the sellers name and contact inforamtion.
                   </p>
               </div>
               <div class = "noMessage" >
                   <p id = "noMessage">
                       <?php 
                       
                       
                       echo "<u>Seller's Name</u>: " .  $sellers_user . "<br><br><u>Preferred Method of Contact</u><br>";
                       
                       echo $product_type . "<br>";
                       
                       ?>

                   </p>
               </div>

           </div>
       </div>
       
       
       
       <div class = "rightFromGallery">
           
           <div id = "title">
               <?php 
               
               echo "<h1>" . $item_name . "</h1>";
               
               ?>
               
           </div>
           
           <div class = "descriptionbox">
               
               <?php 
               
               echo "<p>" . $item_description . "</p>";
               
               ?>
               
               
           </div>
           
           <div class ="details">
               <div class = "Price"> 
                   <h3> Price </h3>
                   <?php 
               
                    echo "<p> $" . $price_listing . "</p>";
               
                    ?>

               </div>
               <div class = "Condition">
                   <h3> Condition of Item </h3>
                   <?php 
                   echo "<p>" . $item_condition . "</p>";
                   
                   ?>

               </div>
               <div class = "ProductType">
                   <h3> Compare Similar Items </h3>
                   

                   
                   <?php
                   
                   $link = "https://www.amazon.com/s?k=" . amazonString($item_name) . "&crid=PHISM0YVT177&sprefix=black+chair%2Caps%2C94&ref=nb_sb_noss_1";
                   
                   echo '<a href = '.$link.'>Amazon Link</a>';

                   
                   ?>

               </div>
           </div>
       
       </div>
       
       
       <div id="footer">
           © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
       </div>
       
       
   </div>

</body>
</html>
<?php

// retrives my (JOHNY) database inforamtion to connect to databse
include_once 'dbConnect.php';


if (isset($_POST['postItem'])){
    
    // puts all textfields into variables
    $name = trim($_POST["name"]);
    $condition = trim($_POST["condition"]);
    $price = (float) $_POST["price"];
    $product = trim($_POST["product"]);
    $comments = trim($_POST["comments"]);
    $username = $_COOKIE["auth"];
    
    
    // creates an array of what was uploaded in the seller page
    $fileNames = array_filter($_FILES['files']['name']);
    
    // checks to see if everything has been filled out in seller page
    if ($name == "" || $condition == ""|| $price == "" || $product == "" || $comments == "" || empty($fileNames)){
        
        // if not then we redirect back to sellers page
        echo "<script>
        window.alert('You are need to fill everything out')
        window.location.href = 'sell.php'
        </script>"; 
    }
    else{
        
        //Select Database
        $mysqli->select_db($dbName) or die($mysqli->error);
        
        $name = $mysqli->real_escape_string($name);
        $condition = $mysqli->real_escape_string($condition);
        $product = $mysqli->real_escape_string($product);
        $comments = $mysqli->real_escape_string($comments);
        $username = $mysqli->real_escape_string($username);
        
        
       // inserts information entered in the seller page to seller database table
        
        $query = "INSERT INTO seller (sellers_user, item_name, item_condition, price_listing, product_type, item_description) VALUES ('$username', '$name', '$condition', '$price', '$product', '$comments')";

        //Execute query 
        $result = $mysqli->query($query) or die($mysqli->error);
        
        
        // save the last id number that was just saved onto the databse because we 
        // need it to give our image database table a connection to the seller page
        $last_id = $mysqli->insert_id;
        $last_id;
        
        
        $targetDir = "picUpload/";
        $extensions = array("jpeg", "jpg", "png");
        $statusMsg = $errorMsg = $insertValueSql = $errorUpload = $errorUploadType = "";
        
        $counter = 0;
        foreach($fileNames as $key=>$val){
            //File upload path
            $fileName = basename($_FILES['files']['name'][$key]);
            // File extension
            $file_ext = strtolower(end(explode('.', $fileName)));

            
            
            // if extension is in the extension array then the file is good to upload to databse
            if (in_array($file_ext, $extensions)){
                
                // first image will be the primary image that will be used for the search image of the item
                if ($counter == 0){
                    $query = "INSERT INTO images (item_id, sellers_user, primary_img, img_extension) VALUES ('$last_id', '$username', 1, '$file_ext')";
                }
                // primary image isnt needed for anything other than the first iamge, it defaults to 0, which is false in the databse
                else{
                    $query = "INSERT INTO images (item_id, sellers_user, img_extension) VALUES ('$last_id', '$username', '$file_ext')";
                
                }
            

                //Execute query 
                // Upload to images table
                $result = $mysqli->query($query) or die($mysqli->error);
                
                // get the id of the last id uploaded
                $last_img_id = $mysqli->insert_id;
        
                $last_img_id;
                
                // the new name for the image will be the id number + the extension of the file
                if (move_uploaded_file($_FILES["files"]["tmp_name"][$key], $targetDir . strval($last_img_id))){
                    // raise counter if image sucessfully uploaded to database
                    $counter++;
                    
                }
                else{
                    
                    // if for some reason image didnt upload correctly we delete the associated 
                    // id from the images database table
                    
                    
                    $query = "SELECT image_id FROM images WHERE image_id='$last_img_id'";
                    
                    $result = $mysqli->query($query) or die($mysqli->error);
                    
                    $exists = False;
                    while($row = $result->fetch_row()) {
                        $exists = True;
                        $id_row = $row[0];
                    }
                    
                    if($exists) {
                        $query = "DELETE FROM images WHERE image_id='$last_img_id'";
                        //Execute query 
                        $result = $mysqli->query($query) or die($mysqli->error);
                        //found
                    }

                }
                
                
            }
            

        }
        
        // if everything works out fine we send to the home page
        echo "<script>
        
        window.location.href = 'home.php'
        </script>"; 
        
    }

}


    
    
    


?>

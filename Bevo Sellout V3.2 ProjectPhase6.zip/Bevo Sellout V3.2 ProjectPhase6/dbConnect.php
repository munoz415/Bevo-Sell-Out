<?php


$server = "spring-2022.cs.utexas.edu";
$user   = "cs329e_bulko_jh68526";
$pwd    = "Club8Pillow2affect";
$dbName = "cs329e_bulko_jh68526";

$mysqli = new mysqli ($server,$user,$pwd,$dbName);

if ($mysqli->connect_errno) {
    die('Connect Error: ' . $mysqli->connect_errno . ": " . $mysqli->connect_error);
}

?>
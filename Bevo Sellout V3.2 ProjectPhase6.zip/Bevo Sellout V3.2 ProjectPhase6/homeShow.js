var img_src = new Array(
    "chair.png",
    "coffeemaker.jpg",
    "decor.png",
    "desk.jpg",
    "lamp.jpg",
    "table.jpg"
  );
  
  var isShowOn = true;
  var idx = 1;
  
  var interval
  
  function startShow() {
    isShowOn = true;
    runShow();
  }
  
  function runShow() {
    interval = setInterval(function () {
      if (isShowOn == true) {
        document.getElementById("image").src = img_src[idx];
        console.log("change");
        idx += 1;
        if (idx == img_src.length) {
          idx = 0;
        }
      }
    }, 3000);
  }
  
  function stopShow() {
    isShowOn = false;
    clearInterval(interval);
  }
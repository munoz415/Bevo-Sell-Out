<?php
    if(isset($_POST['search'])) {

       $valueToSearch = $_POST['valueToSearch'];

       $query = "SELECT * FROM seller WHERE item_name LIKE '%$valueToSearch%'";

       $search_result = filterTable($query);

    }

    else {
       $query = "SELECT * FROM seller";
       $search_result = filterTable($query);
    }


   function filterTable($query)
   {
   $connect = mysqli_connect("spring-2022.cs.utexas.edu", "cs329e_bulko_jh68526", "Club8Pillow2affect", "cs329e_bulko_jh68526");
   $filter_Result = mysqli_query($connect, $query);
   return $filter_Result;
   }

   function imageId($id)
   {
    $connect = mysqli_connect("spring-2022.cs.utexas.edu", "cs329e_bulko_jh68526", "Club8Pillow2affect", "cs329e_bulko_jh68526");
    $query_image = "SELECT * FROM images WHERE image_id=$id";
    $filter_Result_image = mysqli_query($connect, $query_image);
    
    $imageLink = 'picUpload/' + $filter_Result_image['image_id'] + '.' + $filter_Result_image['image_extension'];

    return $imageLink;
   }

   function amazonString($itemStr)
   {
    return str_replace(' ', '+', $itemStr);
   }

?>



<!DOCTYPE html>

<html lang="en">

<head>
   <title>Search Page</title>
   <meta charset="UTF-8">
   <meta name="description" content="Item Page">
   <meta name="author" content="Harper DeLoach">
   
   <link href="search.css" rel="stylesheet">
   <script type="text/javascript" src="search.js"> </script>
   <script src = "jquery-3.6.0.js"></script>
</head> 

<body>

   <div id="container">
      <div id="top">
          <a href="home.php"><img id="logo" src="logo.png" ></a>
          <?php
          if(!isset($_COOKIE["auth"])) {
              echo '<a id="signup" href="register.html">Register</a>
              <a id="signup" href="login.html">Login</a>';
          } else {
              echo '<a id="signup" href="logout.php">Log out</a>';
          }
          ?>
          <a href="home.html"><h1>BEVO SELL-OUT</h1></a>
      </div>        
      
      <div class="navbar">
          <div class="dropdown">
              <button class="dropbtn">About Us 
                  <i class="fa fa-caret-down"></i>
              </button>
          <div class="dropdown-content">
              <a href="aboutusTasmi.php">Tasmi</a>
              <a href="aboutusJohny.php">Johny</a>
              <a href="aboutusHarper.php">Harper</a>
              <a href="aboutusMark.php">Mark</a>
              <a href="aboutusGroup.php">Group 24</a>
              
          </div>
          </div>
          
            <a href="home.php">Home</a>
            <a href="bookmarks.php">Bookmarks</a>
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
       </div>



  <form action="search.php" method="post">

    <input type="text" name="valueToSearch" placeholder="Item">
    <br><br>
    <input type="submit" name="search" value="Search Items"><br><br>

    <table class="results" border="1px solid grey;">
        <tr>
            <td>Item</td>
            <td>Picture</td>
            <td>Condition</td>
            <td>Price</td>
            <td>New Options</td>
       </tr>

      <?php while($row = mysqli_fetch_array($search_result)):?>
          <tr>
              <td><?php echo $row['item_name'];?></td>
              <td>placeholder</td>
              <td><?php echo $row['item_condition'];?></td>
              <td><?php echo $row['price_listing'];?></td>
              <td><a href="https://www.amazon.com/s?k=

                <?php echo amazonString($row['item_name']) ; ?>

                &crid=PHISM0YVT177&sprefix=black+chair%2Caps%2C94&ref=nb_sb_noss_1">Amazon Link</a></td>
          </tr>
      <?php endwhile;?>

    </table>
  </form>
      
       <div id="footer">
            © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
       </div>
       
   </div>

</body>
<?php 

    $server = "spring-2022.cs.utexas.edu";
    $user   = "cs329e_bulko_mam25499";
    $pwd    = "Sweden*React-Clay";
    $dbName = "cs329e_bulko_mam25499";

 // Connects to Our Database 
$link = new mysqli($server, $user, $pwd, $dbName);

/* check connection */
if (mysqli_connect_errno()) {
    echo "Could not connect to database, please check your connection details";
    exit();
}

 ?> 
<?php
    error_reporting(E_ALL);
    ini_set("display_errors", "on");
    
    $server = "spring-2022.cs.utexas.edu";
    $user   = "cs329e_bulko_mam25499";
    $pwd    = "Sweden*React-Clay";
    $dbName = "cs329e_bulko_mam25499";
    
    // Connect to MySQL Server
 
    $mysqli = new mysqli($server, $user, $pwd, $dbName);
 
    if ($mysqli->connect_errno) {
       die('Connect Error: ' . $mysqli->connect_errno . ": " .  $mysqli->connect_error);
    }
   
    //Select Database
    $mysqli->select_db($dbName) or die($mysqli->error);
    
    // Retrieve data from Query String and Post
    $name = $_POST['name'];
    $password = $_POST['password'];
    
    // Escape User Input to help prevent SQL Injection
    $name = $mysqli->real_escape_string($name);
    $password = $mysqli->real_escape_string($password);

    //build query 
    $query = "INSERT INTO projPass VALUES ('$name', '$password')";

    //Execute query 
    $result = $mysqli->query($query) or die($mysqli->error);

    //set cookie
    setcookie("auth", $name, time() + 60*2);

    //print string
    echo "<script>
	window.alert('Registration was successful')
	window.location.href = 'home.php'
	</script>"; 
?>


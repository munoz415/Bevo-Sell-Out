<?php
    $name = $_POST["name"];
    $password = $_POST["password"];
    $repeat = $_POST["repeatPassword"];

    if($password != $repeat) {
        echo '<script>
	    window.alert("Passwords do not match")
	    window.location.href = "register.html"
	</script>';  
    } else {
        //save name and password to database
        $file = fopen("passwd.txt", "a");
        $out = $name . ":". $password . "\n";
        fwrite($file, $out);
        fclose($file);
        //cookie only set for two minutes for testing purposes
        setcookie("auth", $name, time() + 60*2);
        echo'<script>
	    window.alert("Registration was successful")
	    window.location.href = "home.html"
        </script>'; 
    }
?>

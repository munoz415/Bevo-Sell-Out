<!DOCTYPE html>

<html lang="en">

<head>
   <title>Search Page</title>
   <meta charset="UTF-8">
   <meta name="description" content="Item Page">
   <meta name="author" content="Harper DeLoach">
   
   <link href="search.css" rel="stylesheet">
   <script type="text/javascript" src="search.js"> </script>
   <script src = "jquery-3.6.0.js"></script>
</head> 

<body onload = "notInterestedText()">

   <div id="container">
      <div id="top">
          <a href="home.html"><img id="logo" src="logo.png" ></a>
          <?php
          if(!isset($_COOKIE["auth"])) {
              echo '<a id="signup" href="register.html">Register</a>
              <a id="signup" href="login.html">Login</a>';
          } else {
              echo '<a id="signup" href="logout.php">Log out</a>';
          }
          ?>
          <a href="home.html"><h1>BEVO SELL-OUT</h1></a>
      </div>        
      
      <div class="navbar">
          <div class="dropdown">
              <button class="dropbtn">About Us 
                  <i class="fa fa-caret-down"></i>
              </button>
          <div class="dropdown-content">
              <a href="aboutusTasmi.php">Tasmi</a>
              <a href="aboutusJohny.php">Johny</a>
              <a href="aboutusHarper.php">Harper</a>
              <a href="aboutusMark.php">Mark</a>
              <a href="aboutusGroup.php">Group 24</a>
              
          </div>
          </div>
          
            <a href="home.php">Home</a>
            <a href="bookmarks.php">Bookmarks</a>
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
       </div>

      <div class='results'>
         <table>
            <tr>
               <td><input type="text" id="search_bar" name="search_bar" placeholder="Search For items"></td>
               <td><button id="search_button">Search</button></td>
            </tr>
         </table>
         <br>
         <div id="results">
         </div>
      </div>


       
   </div>

</body>

<script>
   $("#search_button").on('click', function (e) {
    e.preventDefault();
    var resultsDiv = $("#results");
    resultsDiv.html("");
    var Table = $("<table>", {
        "id": "newTable"
    }).appendTo(resultsDiv);
    var rowCount = itemDetails.length;
    var colmCount = itemDetails[0].length;

    // For loop for adding header .i.e th to our table
    for (var k = 0; k < 1; k++) {
        var tablePop = $("<tr>", {
            "class": "trClass"
        }).appendTo(Table);
        for (var j = 0; j < colmCount; j++) {
            $("<th>", {
                "class": "thClass"
            }).prependTo(tablePop).html(itemDetails[k][j]);
        }
    }

    //For loop for adding data .i.e td with data to our dynamic generated table
    for (var i = 1; i < rowCount; i < i++) {
        var tablePop = $("<tr>", {
            "class": "trClass"
        }).appendTo(Table);
        for (var j = 0; j < colmCount; j++) {
            $("<td>", {
            "class": "tdClass"
            }).appendTo(tablePop).html(itemDetails[i][j]);
             
        }
    }
});
</script>
</html>
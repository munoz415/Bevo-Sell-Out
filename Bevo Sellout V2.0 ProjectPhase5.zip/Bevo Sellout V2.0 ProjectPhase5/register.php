<?php
$username = $_POST["name"];
$password = $_POST["password"];
$repeatPassword = $_POST["repeatPassword"];
$existUsername = false;


if($password != $repeatPassword) {
    echo '<script>
    window.alert("Passwords do not match")
    window.location.href = "register.html"
    </script>';  
} 
else {
    
    $passwordfile = fopen("passwd.txt", "r");
    while(!feof($passwordfile)) {
        $line = fgets($passwordfile);
        $split = explode(":", $line);
        if(trim($split[0]) == trim($username)){
            
            $existUsername = true;
                
                
            echo '<script>
            window.alert("Username exist, please use a different one")
            window.location.href = "register.html"
            </script>';
                
        }
    }
        
    fclose($file);
        
    if (!$existUsername){
        $file = fopen("passwd.txt", "a");
        $out = $username . ":". $password . "\n";
        fwrite($file, $out);
        fclose($file);
        setcookie("auth", $username, time() + 60*2);
        echo'<script>
        window.alert("Registration was successful")
        window.location.href = "home.php"
        </script>'; 
    }       
}
?>


<!DOCTYPE html>

<html lang="en">

<head>
   <title>Item Page</title>
   <meta charset="UTF-8">
   <meta name="description" content="Item Page">
   <meta name="author" content="Johnathan Huijon">
   
   <link href="item.css" rel="stylesheet">
   <script type="text/javascript" src="item.js"> </script>
</head> 

<body onload = "notInterestedText()">

   <div id="container">
      <div id="top">
            <a href="home.php"><img id="logo" src="logo.png" ></a>
            <?php
            if(!isset($_COOKIE["auth"])) {
                echo '<a id="signup" href="register.php">Register</a>
                <a id="signup" href="login.html">Login</a>';
            } else {
                echo '<a id="signup" href="logout.php">Log out</a>';
            }
            ?>
            <a href="home.php"><h1>BEVO SELL-OUT</h1></a>
      </div>        
      
      <div class="navbar">
          <div class="dropdown">
              <button class="dropbtn">About Us 
                  <i class="fa fa-caret-down"></i>
              </button>
          <div class="dropdown-content">
              <a href="aboutusTasmi.php">Tasmi</a>
              <a href="aboutusJohny.php">Johny</a>
              <a href="aboutusHarper.php">Harper</a>
              <a href="aboutusMark.php">Mark</a>
              <a href="aboutusGroup.php">Group 24</a>
              
          </div>
          </div>
          
            <a href="home.php">Home</a>
            <a href="bookmarks.php">Bookmarks</a>
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
       </div>
       
       <div class = "leftSide">
           
           <div class = "gallery">
               <span class="helper"></span><img name = "galleryImage" id = "image" src="chair.png">
           </div>
           
           <div class = galleryButtons>
               
               <button type="button" id="start" onclick="leftChange()">&lt;</button>
               <button type="button" id="start" onclick="rightChange()">&#62;</button>
               
           </div>
           
           <div class = "ContactInfo">
               
               <div class = "interestButton">
                   <button type="button" id="interest" onclick="changeText()">Interested In Buying?</button>
               </div>
               <div class = "interestedMessage">
                   <p id = "interestedMessage">
                       Pressing this button will reveal the sellers contact inforamtion. An email will also be sent to the seller with your contact information. 
                   </p>
               </div>
               <div class = "noMessage" >
                   <p id = "noMessage">
                       <u>Seller's Name</u>: Johnathan Huijon<br><br><u>Preferred Method of Contact</u><br>
                       Email: johnathan.huijon@utexas.edu<br>
                       Text Message: 512-123-4567
                   </p>
               </div>

           </div>
       </div>
       
       
       
       <div class = "rightFromGallery">
           
           <div id = "title">
               <h1> Office Chair </h1>
           </div>
           
           <div class = "descriptionbox">
               <p> *Description goes here about the product.* I bought this item on etsy during the start of the covid pandemic. The height of this item is 84 inches, the width is 50 inches and the length is also 50 inches. It wasnt used that much which is why I am seeing if anyone wants to take it from me. </p>
               
               
           </div>
           
           <div class ="details">
               <div class = "Price"> 
                   <h3> Price </h3>
                   <p> $25 </p>
               </div>
               <div class = "Condition">
                   <h3> Condition of Item </h3>
                   <p> Good </p>
               </div>
               <div class = "ProductType">
                   <h3> Product Type </h3>
                   <p> Chair </p>
               </div>
           </div>
       
       </div>
       
       
       <div id="footer">
           © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
       </div>
       
       
   </div>

</body>
</html>
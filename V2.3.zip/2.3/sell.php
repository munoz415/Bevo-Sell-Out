<!DOCTYPE html>

<html lang="en">

<head>
   <title>Selling Form</title>
   <meta charset="UTF-8">
   <meta name="description" content="Sell">
   <meta name="author" content="Johnathan Huijon">
    <link href="sell.css" rel = "stylesheet">
</head> 

<body>
    <div id="container">
        <div id="top">
            <a href="home.html"><img id="logo" src="logo.png" ></a>
            <?php
            if(!isset($_COOKIE["auth"])) {
                echo '<a id="signup" href="register.html">Register</a>
                <a id="signup" href="login.html">Login</a>';
            } else {
                echo '<a id="signup" href="logout.php">Log out</a>';
            }
            ?>
            <a href="home.html"><h1>BEVO SELL-OUT</h1></a>
            
        </div> 
        
        
        <div class="navbar">
              <div class="dropdown">
                <button class="dropbtn">About Us 
                    <i class="fa fa-caret-down"></i>
                </button>
            <div class="dropdown-content">
                <a href="aboutusTasmi.php">Tasmi</a>
                <a href="aboutusJohny.php">Johny</a>
                <a href="aboutusHarper.php">Harper</a>
                <a href="aboutusMark.php">Mark</a>
                <a href="aboutusGroup.php">Group 24</a>
                
            </div>
            </div>
            
          
            <a href="home.php">Home</a>
            <a href="bookmarks.php">Bookmarks</a>
            <a href="sell.php">Sell</a>
            <a href="search.php">Search</a>
        </div> 
        
        <form action = "sellphp.php" method="POST" enctype = "multipart/form-data">
            
        <div class = "leftNav">
            
            

            
            <?php
            if(isset($_COOKIE["auth"])) {
                
                echo "<h2>Directions</h2>",
                
                "<p> Fill out the following questions about the item you are trying to sell and upload a picture of the product for viewers to see. Once the form is completed users will be able to view your listing and contact you about purchasing the item. </p>",
                
                "<input type=\"file\" name = \"files[]\" multiple >",
                //"<input type=\"file\" name = \"files\" >",
                
//                "<button id=\"button\" type=\"button\" onclick=\"getImage()\"> Upload Picture </button><br><br>",
                "<img id= \"placeholder\" src=\"empty.jpg\" style=\"width: 70%\">";
            }
            ?>
            

        
        
        </div>
        
        <div class="rightNav">
            
            
            
<!--            <form method = "POST" action="sellphp.php">-->
                
                <?php
                if(isset($_COOKIE["auth"])) {
                    echo "<h3>Name of Product</h3>",
                    
                    "<label><input name = \"name\" type = \"text\" size = \"30\"> </label><br>",
                    
                    "<h3>Condition</h3>",
                    
                    "<div class=\"checkboxes\">",
                        "<label><input name=\"condition\" type=\"text\" size=\"30\"></label>",
                    "</div>",
                    
                    "<h3>Price Listing</h3>",
                    "<label><input name = \"price\" type = \"text\" size = \"10\"> </label><br>",
                    
                    "<h3>Product Type</h3>",
                    "<label><input name=\"product\" type=\"text\" size=\"30\"></label>",
                    
                    "<h3>Description</h3>",
                    "<p> Please provide as much detail about the product as possible, Such as where you bought it, dimensions of product, color of item, etc. </p>",
                
                    "<textarea name = \"comments\" rows = \"10\" cols = \"60\"></textarea> <br><br>",
                    
                    "<input id=\"button\" name=\"postItem\" type=\"submit\" value=\"Post Item\">",
                        
                    "<input id=\"button\" type = \"reset\" value = \"Clear\" />";
                }
                
                else{
                    
                    echo "<h3>Must Be Logged In To Put Item For Sell!</h3>";
                    
                    
                }
                ?>
                
 
            
            
        </div>
            
        </form> 
        
        

        <div id="footer">
            © 2022 All images and content © Group 24 Images • group24@email.com | Contact Us: 123-456-7890
        </div>
    </div>

</body>
</html>